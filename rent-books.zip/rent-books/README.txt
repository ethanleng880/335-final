Team member: 
Yisheng Leng. 

Directory id: yleng1

App Description: 
This app can help library automatically store what and how many books
that people have rented. User can search what books they want and rent them 
then in our database, we will store this information. Lastly, in the User profile page
if we input user's email, then it will show us what book this user has already rent, 
and we can return any book by clicking return button.

API Links:
https://openlibrary.org/developers/api

Youtube Demo Video:
https://youtu.be/1gXe0_8sU1I